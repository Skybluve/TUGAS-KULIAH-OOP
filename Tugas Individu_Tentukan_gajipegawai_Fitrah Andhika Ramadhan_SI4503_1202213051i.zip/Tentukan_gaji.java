import java.util.Scanner;

public class Tentukan_gaji {

  public static int gaji_pegawai(int golongan) {
    switch (golongan) {
      case 1:
        return 3000000;
      case 2:
        return 4000000;
      case 3:
        return 5000000;
      case 4:
        return 6000000;
      default:
        return 0;
    }
  }

  public static void main(String[] args) {
    int golongan, jumlah_anak;
    double Tunjangan_Istri = 0, Tunjangan_Anak, Gaji_Pokok, Total_gaji_anda;
    String status_pernikahan;

    Scanner input = new Scanner(System.in);
    System.out.print("Apakah jenis golongan anda: ");
    golongan = input.nextInt();
    System.out.print("Apakah status pernikahan anda (ya/tidak): ");
    status_pernikahan = input.next();
    System.out.print("Berapakah jumlah anak anda: ");
    jumlah_anak = input.nextInt();
    Gaji_Pokok = gaji_pegawai(golongan);
    switch (status_pernikahan){
        case "ya":
        
            Tunjangan_Istri = Gaji_Pokok*0.2;
    }
    if(jumlah_anak > 3) {
        System.out.println("Mohon maaf jumlah anak anda melebihi ketentuan yang berlaku,Maximal hanya 3 anak,Terima Kasih"); 
        System.exit(0);
      }
    Tunjangan_Anak = jumlah_anak * 150000;
    Total_gaji_anda = Gaji_Pokok + Tunjangan_Istri + Tunjangan_Anak;
    System.out.println("Gaji Pokok Pegawai : Rp" + Gaji_Pokok);
    System.out.println("Tunjangan Anak: Rp" + Tunjangan_Anak);
    System.out.println("Tunjangan Istri: Rp" + Tunjangan_Istri);
    System.out.println("============= Total Penghasilan Gaji Pegawai============= : Rp" + Total_gaji_anda);
    input.close();
  }
}
